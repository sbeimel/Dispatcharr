"""
MACBridge v3 ENHANCED - Dispatcharr Plugin

KOMPLETT ohne Dispatcharr-Anpassung!
Nutzt Monkey Patching zur Laufzeit.

NEU in v3:
- Auswahl: M3U-Import vs. Direkt-Import
- VOD Pagination Support
- Batch-Import mit Progress
- Erweiterte Optionen
- XMLTV/EPG Import
- MAC-Status Prüfung

Verbindet STB/Stalker-basierte IPTV-Portale mit Dispatcharr.
Unterstützt Live TV, VOD und Serien mit automatischer MAC-Rotation.

modded by StiniStinson
"""

import logging
import requests
from requests.adapters import HTTPAdapter, Retry
from urllib.parse import urlparse
import re
import time

logger = logging.getLogger(__name__)


class STBClient:
    """Client für STB/Stalker Portal API-Kommunikation."""
    
    def __init__(self):
        self._session = None
        self._session_created = 0
        self._SESSION_MAX_AGE = 300
    
    def _get_session(self):
        current_time = time.time()
        if self._session is None or (current_time - self._session_created) > self._SESSION_MAX_AGE:
            if self._session is not None:
                try:
                    self._session.close()
                except:
                    pass
            self._session = requests.Session()
            retries = Retry(total=3, backoff_factor=0.1, status_forcelist=[500, 502, 503, 504])
            self._session.mount("http://", HTTPAdapter(max_retries=retries))
            self._session.mount("https://", HTTPAdapter(max_retries=retries))
            self._session_created = current_time
        return self._session
    
    def get_portal_url(self, url, proxy=None):
        """Ermittelt die Portal-URL aus der Basis-URL."""
        def parse_response(url, data):
            java = data.text.replace(" ", "").replace("'", "").replace("+", "")
            pattern = re.search(r"varpattern.*\/(\(http.*)\/;", java).group(1)
            result = re.search(pattern, url)
            protocol_index = re.search(r"this\.portal_protocol.*(\d).*;", java).group(1)
            ip_index = re.search(r"this\.portal_ip.*(\d).*;", java).group(1)
            path_index = re.search(r"this\.portal_path.*(\d).*;", java).group(1)
            protocol = result.group(int(protocol_index))
            ip = result.group(int(ip_index))
            path = result.group(int(path_index))
            portal_pattern = re.search(r"this\.ajax_loader=(.*\.php);", java).group(1)
            portal = (
                portal_pattern.replace("this.portal_protocol", protocol)
                .replace("this.portal_ip", ip)
                .replace("this.portal_path", path)
            )
            return portal

        url = urlparse(url).scheme + "://" + urlparse(url).netloc
        urls = [
            "/c/xpcom.common.js",
            "/client/xpcom.common.js",
            "/c_/xpcom.common.js",
            "/stalker_portal/c/xpcom.common.js",
            "/stalker_portal/c_/xpcom.common.js",
        ]

        proxies = {"http": proxy, "https": proxy} if proxy else None
        headers = {"User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C)"}

        try:
            session = self._get_session()
            for path in urls:
                try:
                    response = session.get(url + path, headers=headers, proxies=proxies, timeout=10)
                    if response.ok:
                        return parse_response(url + path, response)
                except:
                    continue
        except:
            pass
        return None
    
    def get_token(self, url, mac, proxy=None):
        proxies = {"http": proxy, "https": proxy} if proxy else None
        cookies = {"mac": mac, "stb_lang": "en", "timezone": "Europe/London"}
        headers = {"User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C)"}
        try:
            response = self._get_session().get(
                url + "?type=stb&action=handshake&JsHttpRequest=1-xml",
                cookies=cookies, headers=headers, proxies=proxies, timeout=20,
            )
            token = response.json()["js"]["token"]
            if token:
                logger.info(f"Token erfolgreich für MAC {mac} erhalten")
                return token
        except Exception as e:
            logger.error(f"Fehler beim Token-Abruf für MAC {mac}: {e}")
        return None
    
    def get_profile(self, url, mac, token, proxy=None):
        proxies = {"http": proxy, "https": proxy} if proxy else None
        cookies = {"mac": mac, "stb_lang": "en", "timezone": "Europe/London"}
        headers = {"User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C)", "Authorization": "Bearer " + token}
        try:
            response = self._get_session().get(
                url + "?type=stb&action=get_profile&JsHttpRequest=1-xml",
                cookies=cookies, headers=headers, proxies=proxies, timeout=10,
            )
            return response.json()["js"]
        except:
            return None
    
    def get_expires(self, url, mac, token, proxy=None):
        proxies = {"http": proxy, "https": proxy} if proxy else None
        cookies = {"mac": mac, "stb_lang": "en", "timezone": "Europe/London"}
        headers = {"User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C)", "Authorization": "Bearer " + token}
        try:
            response = self._get_session().get(
                url + "?type=account_info&action=get_main_info&JsHttpRequest=1-xml",
                cookies=cookies, headers=headers, proxies=proxies, timeout=15,
            )
            expires = response.json()["js"]["phone"]
            if expires:
                logger.info(f"Ablaufdatum für MAC {mac}: {expires}")
                return expires
        except Exception as e:
            logger.error(f"Fehler beim Ablaufdatum-Abruf für MAC {mac}: {e}")
        return None
    
    def get_all_channels(self, url, mac, token, proxy=None):
        """Holt alle Live TV Kanäle."""
        proxies = {"http": proxy, "https": proxy} if proxy else None
        cookies = {"mac": mac, "stb_lang": "en", "timezone": "Europe/London"}
        headers = {"User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C)", "Authorization": "Bearer " + token}
        try:
            response = self._get_session().get(
                url + "?type=itv&action=get_all_channels&force_ch_link_check=&JsHttpRequest=1-xml",
                cookies=cookies, headers=headers, proxies=proxies, timeout=30,
            )
            channels = response.json()["js"]["data"]
            if channels:
                logger.info(f"{len(channels)} Kanäle für MAC {mac} erhalten")
                return channels
        except Exception as e:
            logger.error(f"Fehler beim Kanal-Abruf für MAC {mac}: {e}")
        return None
    
    def get_genre_names(self, url, mac, token, proxy=None):
        """Holt Genre-Namen für Live TV."""
        proxies = {"http": proxy, "https": proxy} if proxy else None
        cookies = {"mac": mac, "stb_lang": "en", "timezone": "Europe/London"}
        headers = {"User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C)", "Authorization": "Bearer " + token}
        try:
            response = self._get_session().get(
                url + "?action=get_genres&type=itv&JsHttpRequest=1-xml",
                cookies=cookies, headers=headers, proxies=proxies, timeout=10,
            )
            genre_data = response.json()["js"]
            if genre_data:
                genres = {}
                for item in genre_data:
                    genres[item["id"]] = item["title"]
                return genres
        except:
            pass
        return None


class Plugin:
    """MACBridge v3.0.1 ENHANCED - Mit Dispatcharr-MOD Support!"""
    
    name = "MACBridge v3 ENHANCED"
    version = "v3.0.1"
    description = "STB/Stalker IPTV - Live TV, VOD & Serien (Monkey Patch + MOD Support) modded by StiniStinson"
    
    fields = [
        {
            "id": "portal_name",
            "label": "Portal Name",
            "type": "string",
            "default": "",
            "help_text": "Name des IPTV-Portals"
        },
        {
            "id": "portal_url",
            "label": "Portal URL",
            "type": "string",
            "default": "",
            "help_text": "URL des STB/Stalker-Portals"
        },
        {
            "id": "mac_addresses",
            "label": "MAC-Adressen",
            "type": "string",
            "default": "",
            "help_text": "MAC-Adressen getrennt durch Komma oder Leerzeichen (z.B. '00:1A:79:XX:XX:XX, 00:1A:79:YY:YY:YY' oder '00:1A:79:XX:XX:XX 00:1A:79:YY:YY:YY')"
        },
        {
            "id": "proxy",
            "label": "Proxy (optional)",
            "type": "string",
            "default": "",
            "help_text": "HTTP-Proxy für API-Requests UND M3U Account (MOD: wird als proxy_std_xc gesetzt). Format: http://proxy:8080"
        },
        {
            "id": "country_filter",
            "label": "Ländercode-Filter Live TV & VOD (optional)",
            "type": "string",
            "default": "",
            "help_text": "Nur Kanäle/Kategorien mit diesen Ländercodes (z.B. 'DE, NL, US'). Gilt für Live TV UND VOD."
        },
        {
            "id": "import_method",
            "label": "Import-Methode",
            "type": "select",
            "default": "direct",
            "options": [
                {"value": "direct", "label": "⚡ Direkt-Import (EMPFOHLEN - schnell!)"},
                {"value": "m3u", "label": "⚠️ M3U-Import (LANGSAM - nur für spezielle Fälle!)"}
            ],
            "help_text": "⚡ Direkt: ~2 Min für 500 Filme. ⚠️ M3U: ~25 Min für 500 Filme!"
        },
        {
            "id": "max_items_per_category",
            "label": "Max. Items pro Kategorie",
            "type": "number",
            "default": 0,
            "help_text": "0 = Alle importieren, >0 = Limit pro Kategorie (für Tests)"
        },
        {
            "id": "skip_existing",
            "label": "Existierende überspringen",
            "type": "boolean",
            "default": True,
            "help_text": "Überspringt bereits importierte Filme (schneller)"
        },
        {
            "id": "auto_create_channels",
            "label": "Live TV: Channels automatisch erstellen",
            "type": "boolean",
            "default": False,
            "help_text": "Erstellt automatisch Channels aus Streams (Standard: nur Streams importieren)"
        },
        {
            "id": "channel_profile",
            "label": "Live TV: Channel-Profil Name",
            "type": "string",
            "default": "All",
            "help_text": "Name des Channel-Profils, zu dem die Kanäle hinzugefügt werden sollen (z.B. 'MAC Portal Channels'). Wird automatisch erstellt, falls nicht vorhanden."
        },
        {
            "id": "clean_channel_names",
            "label": "Live TV: Kanalnamen bereinigen",
            "type": "boolean",
            "default": False,
            "help_text": "Entfernt Prefixes (┃DE┃, [UK], DE ✨) UND Sonderzeichen (Emojis ✨🔥⭐, Symbole, Umlaute→ae/oe/ue, Akzente, Kyrillisch, Arabisch, Chinesisch). Standard: Nur Display-Name, tvg-name bleibt Original."
        },
        {
            "id": "clean_tvg_name",
            "label": "Live TV: Auch tvg-name bereinigen",
            "type": "boolean",
            "default": False,
            "help_text": "Bereinigt auch tvg-name (nicht nur Display-Name). ⚠️ WARNUNG: Kann EPG-Matching beeinträchtigen! Nur aktivieren wenn EPG auch bereinigte Namen verwendet."
        },
        {
            "id": "auto_update_enabled",
            "label": "Auto-Update aktivieren",
            "type": "boolean",
            "default": False,
            "help_text": "Aktiviert automatische VOD/Serien-Updates alle X Stunden via Celery Beat"
        },
        {
            "id": "auto_update_interval_hours",
            "label": "Update-Intervall (Stunden)",
            "type": "number",
            "default": 6,
            "help_text": "Intervall für automatische Updates in Stunden (Standard: 6)"
        },
    ]
    
    actions = [
        {
            "id": "test_portal",
            "label": "Portal testen",
            "description": "Testet die Verbindung zum Portal und alle MAC-Adressen",
        },
        {
            "id": "check_mac_status",
            "label": "MAC-Status prüfen",
            "description": "Prüft den Status, Ablaufdatum und Kanal-Prefixes aller MAC-Adressen",
        },
        {
            "id": "import_live_tv",
            "label": "📺 Live TV importieren",
            "description": "Importiert Live TV Streams - SCHNELL! (~1 Min für 500 Channels)",
        },
        {
            "id": "import_xmltv",
            "label": "📡 XMLTV/EPG importieren",
            "description": "Lädt die XMLTV-EPG-Datei vom Portal herunter und registriert EPG-Quelle",
        },
        {
            "id": "import_vod",
            "label": "🎬 VOD importieren",
            "description": "Importiert Filme (Methode aus Settings: Direkt=⚡schnell oder M3U=⚠️langsam)",
        },

        {
            "id": "cleanup_vod",
            "label": "🗑️ VOD/Serien bereinigen",
            "description": "Löscht ALLE importierten VOD-Daten (Filme, Serien, Kategorien)",
        },
        {
            "id": "auto_update_status",
            "label": "⚙️ Auto-Update Status",
            "description": "Zeigt den Status des automatischen Updates und ermöglicht das Aktivieren/Deaktivieren",
        },
    ]
    
    def __init__(self):
        self.stb_client = STBClient()
        self._patch_get_stream_url()
    
    def _patch_get_stream_url(self):
        """Monkey Patch für get_stream_url() - KEINE Dispatcharr-Anpassung nötig!"""
        try:
            from apps.vod.models import M3UMovieRelation, M3UEpisodeRelation
            
            original_movie_get_stream_url = M3UMovieRelation.get_stream_url
            original_episode_get_stream_url = M3UEpisodeRelation.get_stream_url
            
            def patched_movie_get_stream_url(self):
                if self.custom_properties and 'mac_portal_stream_url' in self.custom_properties:
                    logger.debug(f"[MACBridge] Using MAC Portal stream URL from custom_properties")
                    return self.custom_properties['mac_portal_stream_url']
                return original_movie_get_stream_url(self)
            
            def patched_episode_get_stream_url(self):
                if self.custom_properties and 'mac_portal_stream_url' in self.custom_properties:
                    logger.debug(f"[MACBridge] Using MAC Portal stream URL from custom_properties")
                    return self.custom_properties['mac_portal_stream_url']
                return original_episode_get_stream_url(self)
            
            M3UMovieRelation.get_stream_url = patched_movie_get_stream_url
            M3UEpisodeRelation.get_stream_url = patched_episode_get_stream_url
            
            logger.info("✅ [MACBridge v3 ENHANCED] get_stream_url() erfolgreich gepatcht (Monkey Patch)")
            logger.info("✅ [MACBridge v3 ENHANCED] Streaming funktioniert jetzt für MAC Portal!")
            
        except Exception as e:
            logger.error(f"❌ [MACBridge v3 ENHANCED] Fehler beim Monkey Patching: {e}")
            import traceback
            logger.error(traceback.format_exc())
    
    def run(self, action: str, params: dict, context: dict):
        """Führt eine Plugin-Aktion aus."""
        settings = context.get("settings", {})
        logger_ctx = context.get("logger", logger)
        
        portal_url = settings.get("portal_url", "").strip()
        mac_addresses = settings.get("mac_addresses", "").strip()
        
        if not portal_url or not mac_addresses:
            return {"status": "error", "message": "Portal URL und MAC-Adressen sind erforderlich"}
        
        # Parse MACs: Unterstützt Komma UND Leerzeichen als Trenner
        macs = [mac.strip() for mac in re.split(r'[,\s]+', mac_addresses) if mac.strip()]
        proxy = settings.get("proxy", "").strip() or None
        
        if not portal_url.endswith(".php"):
            portal_url = self.stb_client.get_portal_url(portal_url, proxy)
            if not portal_url:
                return {"status": "error", "message": "Konnte Portal-URL nicht ermitteln"}
        
        if action == "test_portal":
            return self._test_portal(portal_url, macs, proxy, logger_ctx)
        
        elif action == "check_mac_status":
            return self._check_mac_status(portal_url, macs, proxy, logger_ctx)
        
        elif action == "import_live_tv":
            portal_name = settings.get("portal_name", "MAC Portal").strip()
            country_filter = settings.get("country_filter", "").strip()
            auto_create_channels = settings.get("auto_create_channels", False)
            channel_profile = settings.get("channel_profile", "All").strip()
            return self._import_live_tv(portal_url, macs, proxy, portal_name, country_filter, auto_create_channels, channel_profile, settings, logger_ctx)
        
        elif action == "import_xmltv":
            portal_name = settings.get("portal_name", "MAC Portal").strip()
            return self._import_xmltv(portal_url, macs, proxy, portal_name, logger_ctx)
        
        elif action == "import_vod":
            # Nutze Settings für Import-Methode
            import_method = settings.get("import_method", "direct")
            portal_name = settings.get("portal_name", "MAC Portal").strip()
            country_filter = settings.get("country_filter", "").strip()
            
            if import_method == "m3u":
                return self._import_vod_m3u(portal_url, macs[0], proxy, portal_name, country_filter, settings, logger_ctx)
            else:
                return self._import_vod_direct(portal_url, macs[0], proxy, portal_name, country_filter, settings, logger_ctx)
        
        elif action == "cleanup_vod":
            return self._cleanup_vod(logger_ctx)
        
        elif action == "auto_update_status":
            return self._show_auto_update_status(settings, logger_ctx)
        
        return {"status": "error", "message": f"Unbekannte Aktion: {action}"}
    
    def _test_portal(self, portal_url, macs, proxy, logger_ctx):
        """Testet die Portal-Verbindung."""
        logger_ctx.info(f"Teste Portal: {portal_url}")
        results = []
        for mac in macs:
            token = self.stb_client.get_token(portal_url, mac, proxy)
            if token:
                expires = self.stb_client.get_expires(portal_url, mac, token, proxy)
                results.append({"mac": mac, "status": "success", "expires": expires})
            else:
                results.append({"mac": mac, "status": "error"})
        success_count = sum(1 for r in results if r["status"] == "success")
        return {
            "status": "success" if success_count > 0 else "error",
            "message": f"{success_count}/{len(macs)} MAC-Adressen erfolgreich getestet",
            "results": results
        }
    
    def _list_vod_categories(self, portal_url, mac, proxy, logger_ctx):
        """Zeigt alle verfügbaren VOD-Kategorien."""
        logger_ctx.info(f"📁 Hole VOD-Kategorien vom Portal...")
        
        try:
            # Hole Token
            token = self.stb_client.get_token(portal_url, mac, proxy)
            if not token:
                return {"status": "error", "message": "Konnte Token nicht abrufen"}
            
            self.stb_client.get_profile(portal_url, mac, token, proxy)
            
            proxies = {"http": proxy, "https": proxy} if proxy else None
            cookies = {"mac": mac, "stb_lang": "en", "timezone": "Europe/London"}
            headers = {
                "User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C)",
                "Authorization": f"Bearer {token}",
            }
            
            # Hole VOD-Kategorien
            vod_cat_url = f"{portal_url}?type=vod&action=get_categories&JsHttpRequest=1-xml"
            response = requests.get(vod_cat_url, headers=headers, cookies=cookies, proxies=proxies, timeout=30)
            
            if response.status_code != 200:
                return {"status": "error", "message": "Fehler beim Abrufen der VOD-Kategorien"}
            
            vod_categories = response.json()["js"]
            
            # Filtere "*" Kategorie raus
            vod_categories = [cat for cat in vod_categories if cat['id'] != "*"]
            
            # Sortiere alphabetisch
            vod_categories.sort(key=lambda x: x['title'])
            
            # Erstelle Liste
            category_names = [cat['title'] for cat in vod_categories]
            
            logger_ctx.info(f"✅ {len(category_names)} Kategorien gefunden")
            
            # Erstelle formatierte Ausgabe
            message_lines = [
                f"📁 {len(category_names)} VOD-Kategorien gefunden:",
                "",
                "Kopiere die gewünschten Kategorien in die Settings:",
                ""
            ]
            
            for i, name in enumerate(category_names, 1):
                message_lines.append(f"{i}. {name}")
            
            message_lines.extend([
                "",
                "💡 Beispiel für Settings:",
                f"  vod_category_include: \"{category_names[0]}, {category_names[1] if len(category_names) > 1 else ''}\"",
                "",
                "Oder alle außer bestimmte:",
                "  vod_category_exclude: \"XXX, Adult, Erotik\""
            ])
            
            return {
                "status": "success",
                "message": "\n".join(message_lines),
                "categories": category_names,
                "total": len(category_names)
            }
            
        except Exception as e:
            logger_ctx.error(f"Fehler: {e}")
            import traceback
            logger_ctx.error(traceback.format_exc())
            return {"status": "error", "message": str(e)}
    
    def _import_vod_direct(self, portal_url, mac, proxy, portal_name, country_filter, settings, logger_ctx):
        """
        Importiert VOD DIREKT in die Datenbank.
        Nutzt Pagination und Batch-Import.
        """
        logger_ctx.info(f"🎬 VOD Direkt-Import vom Portal: {portal_name}")
        
        # Pagination ist immer aktiviert (macht am meisten Sinn)
        use_pagination = True
        max_items = settings.get("max_items_per_category", 0)
        skip_existing = settings.get("skip_existing", True)
        
        logger_ctx.info(f"⚙️ Max Items: {max_items or 'Alle'}, Skip Existing: {skip_existing}")
        
        try:
            from apps.vod.models import VODCategory, Movie, M3UMovieRelation
            from apps.m3u.models import M3UAccount
            
            # Hole Token
            token = self.stb_client.get_token(portal_url, mac, proxy)
            if not token:
                return {"status": "error", "message": "Konnte Token nicht abrufen"}
            
            self.stb_client.get_profile(portal_url, mac, token, proxy)
            
            proxies = {"http": proxy, "https": proxy} if proxy else None
            cookies = {"mac": mac, "stb_lang": "en", "timezone": "Europe/London"}
            headers = {
                "User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C)",
                "Authorization": f"Bearer {token}",
            }
            
            # Hole VOD-Kategorien
            vod_cat_url = f"{portal_url}?type=vod&action=get_categories&JsHttpRequest=1-xml"
            response = requests.get(vod_cat_url, headers=headers, cookies=cookies, proxies=proxies, timeout=30)
            
            if response.status_code != 200:
                return {"status": "error", "message": "Fehler beim Abrufen der VOD-Kategorien"}
            
            vod_categories = response.json()["js"]
            
            # Filtere nach Ländercode
            if country_filter:
                allowed_countries = [c.strip().upper() for c in country_filter.split(",") if c.strip()]
                vod_categories = [cat for cat in vod_categories 
                                if cat['id'] != "*" and self._matches_country_filter(cat['title'], allowed_countries)]
            
            logger_ctx.info(f"📁 {len(vod_categories)} Kategorien gefunden")
            
            # Erstelle M3U Account
            account_name = f"MAC Portal VOD - {portal_name}"
            account_defaults = {
                'account_type': 'MAC',
                'server_url': portal_url,
                'username': mac,
            }
            
            # MOD-Support: Setze proxy in BEIDEN Feldern
            if proxy:
                if hasattr(M3UAccount, 'proxy'):
                    account_defaults['proxy'] = proxy
                if hasattr(M3UAccount, 'proxy_std_xc'):
                    account_defaults['proxy_std_xc'] = proxy
                logger_ctx.info(f"✅ Proxy für M3U Account gesetzt: {proxy}")
            
            m3u_account, created = M3UAccount.objects.get_or_create(
                name=account_name,
                defaults=account_defaults
            )
            
            # Update proxy bei existierendem Account (BEIDE Felder)
            if not created and proxy:
                if hasattr(m3u_account, 'proxy'):
                    m3u_account.proxy = proxy
                if hasattr(m3u_account, 'proxy_std_xc'):
                    m3u_account.proxy_std_xc = proxy
                m3u_account.save()
                logger_ctx.info(f"✅ Proxy für M3U Account aktualisiert: {proxy}")
            
            logger_ctx.info(f"✅ M3U Account: {account_name}")
            
            total_movies = 0
            total_skipped = 0
            
            # Importiere Filme pro Kategorie
            for cat_idx, category in enumerate(vod_categories, 1):
                if category['id'] == "*":
                    continue
                
                logger_ctx.info(f"📁 [{cat_idx}/{len(vod_categories)}] {category['title']}")
                
                vod_category, _ = VODCategory.objects.get_or_create(
                    name=category['title'],
                    defaults={'category_type': 'movie'}
                )
                
                # Hole Filme mit Pagination
                page = 1
                category_movies = 0
                
                while True:
                    if max_items > 0 and category_movies >= max_items:
                        logger_ctx.info(f"  ⏹️ Limit erreicht ({max_items} Filme)")
                        break
                    
                    # Hole Seite
                    vod_url = f"{portal_url}?type=vod&action=get_ordered_list&category={category['id']}&sortby=added&p={page}&JsHttpRequest=1-xml"
                    
                    try:
                        response = requests.get(vod_url, headers=headers, cookies=cookies, proxies=proxies, timeout=60)
                    except Exception as e:
                        logger_ctx.warning(f"  ⚠️ Timeout Seite {page}: {e}")
                        break
                    
                    if response.status_code != 200:
                        break
                    
                    vod_items = response.json()["js"]["data"]
                    
                    if not vod_items:
                        break
                    
                    logger_ctx.info(f"  📄 Seite {page}: {len(vod_items)} Filme")
                    
                    # Batch-Import
                    for item in vod_items:
                        if max_items > 0 and category_movies >= max_items:
                            break
                        
                        try:
                            # Prüfe ob existiert
                            if skip_existing and Movie.objects.filter(name=item.get('name')).exists():
                                total_skipped += 1
                                continue
                            
                            cmd = item.get('cmd', '')
                            if not cmd:
                                continue
                            
                            # Hole Stream-URL
                            stream_url_response = requests.get(
                                f"{portal_url}?type=vod&action=create_link&cmd={cmd}&JsHttpRequest=1-xml",
                                headers=headers, cookies=cookies, proxies=proxies, timeout=10
                            )
                            
                            if stream_url_response.status_code != 200:
                                continue
                            
                            stream_url = stream_url_response.json()["js"].get("cmd", "").split()[-1]
                            
                            if not stream_url or not stream_url.startswith("http"):
                                continue
                            
                            # Erstelle Movie
                            movie, _ = Movie.objects.get_or_create(
                                name=item.get('name', 'Unknown'),
                                defaults={
                                    'description': item.get('description', ''),
                                    'year': self._extract_year(item.get('year')),
                                    'custom_properties': {
                                        'mac_portal_stream_url': stream_url,
                                        'mac_portal_id': item.get('id'),
                                        'mac_portal_name': portal_name,
                                    }
                                }
                            )
                            
                            # Erstelle Relation
                            M3UMovieRelation.objects.update_or_create(
                                m3u_account=m3u_account,
                                stream_id=item.get('id', ''),
                                defaults={
                                    'movie': movie,
                                    'category': vod_category,
                                    'container_extension': 'mp4',
                                    'custom_properties': {
                                        'mac_portal_stream_url': stream_url,
                                    }
                                }
                            )
                            
                            total_movies += 1
                            category_movies += 1
                            
                        except Exception as e:
                            logger_ctx.debug(f"Fehler: {e}")
                            continue
                    
                    if not use_pagination:
                        break
                    
                    page += 1
                
                logger_ctx.info(f"  ✅ {category_movies} Filme importiert")
            
            logger_ctx.info(f"🎉 Import abgeschlossen: {total_movies} Filme, {total_skipped} übersprungen")
            
            return {
                "status": "success",
                "message": f"✅ {total_movies} Filme importiert, {total_skipped} übersprungen",
                "total_movies": total_movies,
                "total_skipped": total_skipped,
                "method": "direct",
                "pagination_used": use_pagination
            }
            
        except Exception as e:
            logger_ctx.error(f"Fehler: {e}")
            import traceback
            logger_ctx.error(traceback.format_exc())
            return {"status": "error", "message": str(e)}
    
    def _import_vod_m3u(self, portal_url, mac, proxy, portal_name, country_filter, settings, logger_ctx):
        """
        Generiert M3U-Datei für VOD und erstellt M3U-Account in Dispatcharr.
        
        ⚠️ WARNUNG: M3U-Import ist SEHR LANGSAM!
        - Muss für jeden Film Stream-URL vorab holen
        - 500 Filme = ~25 Minuten
        - 5000 Filme = ~3 Stunden
        
        💡 EMPFEHLUNG: Nutze Direkt-Import (viel schneller!)
        """
        logger_ctx.info(f"🎬 VOD M3U-Import vom Portal: {portal_name}")
        logger_ctx.warning("⚠️ M3U-Import ist SEHR LANGSAM! Direkt-Import ist 10x schneller!")
        
        # Pagination ist immer aktiviert (macht am meisten Sinn)
        use_pagination = True
        max_items = settings.get("max_items_per_category", 0)
        
        logger_ctx.info(f"⚙️ Max Items: {max_items or 'Alle'}")
        
        try:
            import os
            from apps.m3u.models import M3UAccount
            
            # Hole Token
            token = self.stb_client.get_token(portal_url, mac, proxy)
            if not token:
                return {"status": "error", "message": "Konnte Token nicht abrufen"}
            
            self.stb_client.get_profile(portal_url, mac, token, proxy)
            
            proxies = {"http": proxy, "https": proxy} if proxy else None
            cookies = {"mac": mac, "stb_lang": "en", "timezone": "Europe/London"}
            headers = {
                "User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C)",
                "Authorization": f"Bearer {token}",
            }
            
            # Hole VOD-Kategorien
            vod_cat_url = f"{portal_url}?type=vod&action=get_categories&JsHttpRequest=1-xml"
            response = requests.get(vod_cat_url, headers=headers, cookies=cookies, proxies=proxies, timeout=30)
            
            if response.status_code != 200:
                return {"status": "error", "message": "Fehler beim Abrufen der VOD-Kategorien"}
            
            vod_categories = response.json()["js"]
            
            # Filtere nach Ländercode
            if country_filter:
                allowed_countries = [c.strip().upper() for c in country_filter.split(",") if c.strip()]
                vod_categories = [cat for cat in vod_categories 
                                if cat['id'] != "*" and self._matches_country_filter(cat['title'], allowed_countries)]
            
            logger_ctx.info(f"📁 {len(vod_categories)} Kategorien gefunden")
            
            # Generiere M3U-Content
            m3u_lines = ['#EXTM3U']
            total_movies = 0
            
            safe_portal_name = "".join(c if c.isalnum() or c in (' ', '-', '_') else '_' for c in portal_name)
            
            # Sammle Filme pro Kategorie
            for cat_idx, category in enumerate(vod_categories, 1):
                if category['id'] == "*":
                    continue
                
                logger_ctx.info(f"📁 [{cat_idx}/{len(vod_categories)}] {category['title']}")
                
                category_movies = 0
                page = 1
                
                while True:
                    if max_items > 0 and category_movies >= max_items:
                        logger_ctx.info(f"  ⏹️ Limit erreicht ({max_items} Filme)")
                        break
                    
                    # Hole Seite
                    vod_url = f"{portal_url}?type=vod&action=get_ordered_list&category={category['id']}&sortby=added&p={page}&JsHttpRequest=1-xml"
                    
                    try:
                        response = requests.get(vod_url, headers=headers, cookies=cookies, proxies=proxies, timeout=60)
                    except Exception as e:
                        logger_ctx.warning(f"  ⚠️ Timeout Seite {page}: {e}")
                        break
                    
                    if response.status_code != 200:
                        break
                    
                    vod_items = response.json()["js"]["data"]
                    
                    if not vod_items:
                        break
                    
                    logger_ctx.info(f"  📄 Seite {page}: {len(vod_items)} Filme")
                    logger_ctx.info(f"  ⏳ Hole Stream-URLs (kann lange dauern)...")
                    
                    # Verarbeite Filme
                    for item in vod_items:
                        if max_items > 0 and category_movies >= max_items:
                            break
                        
                        try:
                            cmd = item.get('cmd', '')
                            if not cmd:
                                continue
                            
                            # Hole Stream-URL (LANGSAM!)
                            stream_url_response = requests.get(
                                f"{portal_url}?type=vod&action=create_link&cmd={cmd}&JsHttpRequest=1-xml",
                                headers=headers, cookies=cookies, proxies=proxies, timeout=10
                            )
                            
                            if stream_url_response.status_code != 200:
                                continue
                            
                            stream_url = stream_url_response.json()["js"].get("cmd", "").split()[-1]
                            
                            if not stream_url or not stream_url.startswith("http"):
                                continue
                            
                            # Erstelle EXTINF-Zeile
                            movie_name = item.get('name', 'Unknown')
                            movie_id = item.get('id', '')
                            logo = item.get('screenshot_uri', '')
                            year = item.get('year', '')
                            
                            extinf_parts = ['#EXTINF:-1']
                            
                            # Metadaten
                            extinf_parts.append(f'tvg-id="{safe_portal_name.lower().replace(" ", "_")}_{movie_id}"')
                            extinf_parts.append(f'tvg-name="{movie_name}"')
                            
                            if logo:
                                extinf_parts.append(f'tvg-logo="{logo}"')
                            
                            extinf_parts.append(f'group-title="{category["title"]}"')
                            
                            if year:
                                extinf_parts.append(f'tvg-year="{year}"')
                            
                            # Custom Properties für Monkey Patch
                            extinf_parts.append(f'mac-portal-id="{movie_id}"')
                            extinf_parts.append(f'mac-portal-name="{portal_name}"')
                            
                            extinf_line = ' '.join(extinf_parts) + f',{movie_name}'
                            m3u_lines.append(extinf_line)
                            m3u_lines.append(stream_url)
                            
                            total_movies += 1
                            category_movies += 1
                            
                        except Exception as e:
                            logger_ctx.debug(f"Fehler: {e}")
                            continue
                    
                    if not use_pagination:
                        break
                    
                    page += 1
                
                logger_ctx.info(f"  ✅ {category_movies} Filme hinzugefügt")
            
            m3u_content = '\n'.join(m3u_lines)
            
            # Speichere M3U-Datei
            output_dir = "/app/sources"
            if not os.path.exists(output_dir):
                output_dir = os.path.join(os.getcwd(), "sources")
                os.makedirs(output_dir, exist_ok=True)
            
            safe_filename = safe_portal_name.replace(' ', '_')
            output_file = os.path.join(output_dir, f"{safe_filename}_vod.m3u")
            
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(m3u_content)
            
            logger_ctx.info(f"✅ M3U-Datei gespeichert: {output_file}")
            
            # Erstelle M3U-Account in Dispatcharr
            account_name = f"MAC Portal VOD - {portal_name}"
            
            existing_account = M3UAccount.objects.filter(name=account_name).first()
            
            if existing_account:
                logger_ctx.info(f"Account existiert bereits, aktualisiere: {account_name}")
                existing_account.url = f"file://{output_file}"
                
                # MOD-Support: Update proxy in BEIDEN Feldern
                if proxy:
                    if hasattr(existing_account, 'proxy'):
                        existing_account.proxy = proxy
                    if hasattr(existing_account, 'proxy_std_xc'):
                        existing_account.proxy_std_xc = proxy
                    logger_ctx.info(f"✅ Proxy für M3U Account aktualisiert: {proxy}")
                
                existing_account.save()
                account_id = existing_account.id
            else:
                logger_ctx.info(f"Erstelle neuen M3U-Account: {account_name}")
                new_account = M3UAccount(name=account_name)
                
                # Setze Account-Type
                if hasattr(new_account, 'account_type'):
                    new_account.account_type = 'STD'
                
                # Setze URL/Path (verschiedene Dispatcharr-Versionen)
                if hasattr(new_account, 'url'):
                    new_account.url = f"file://{output_file}"
                elif hasattr(new_account, 'file_path'):
                    new_account.file_path = output_file
                elif hasattr(new_account, 'path'):
                    new_account.path = output_file
                
                # MOD-Support: Setze proxy in BEIDEN Feldern
                if proxy:
                    if hasattr(new_account, 'proxy'):
                        new_account.proxy = proxy
                    if hasattr(new_account, 'proxy_std_xc'):
                        new_account.proxy_std_xc = proxy
                    logger_ctx.info(f"✅ Proxy für M3U Account gesetzt: {proxy}")
                
                new_account.save()
                account_id = new_account.id
            
            logger_ctx.info(f"✅ M3U-Account erstellt/aktualisiert: {account_name} (ID: {account_id})")
            
            # Trigger Refresh
            try:
                from apps.m3u.tasks import refresh_m3u_account
                refresh_m3u_account.delay(account_id)
                logger_ctx.info(f"✅ Refresh-Task gestartet für Account {account_id}")
            except Exception as refresh_error:
                logger_ctx.debug(f"Konnte Refresh-Task nicht starten: {refresh_error}")
            
            logger_ctx.info(f"🎉 M3U-Import abgeschlossen: {total_movies} Filme")
            
            return {
                "status": "success",
                "message": f"✅ M3U-Datei mit {total_movies} Filmen erstellt (⚠️ Nutze Direkt-Import für schnelleren Import!)",
                "total_movies": total_movies,
                "account_id": account_id,
                "account_name": account_name,
                "file_path": output_file,
                "method": "m3u",
                "pagination_used": use_pagination
            }
            
        except Exception as e:
            logger_ctx.error(f"Fehler: {e}")
            import traceback
            logger_ctx.error(traceback.format_exc())
            return {"status": "error", "message": str(e)}
    
    def _cleanup_vod(self, logger_ctx):
        """Löscht alle MAC Portal VOD-Daten."""
        try:
            from apps.vod.models import Movie, M3UMovieRelation
            from apps.m3u.models import M3UAccount
            
            relations = M3UMovieRelation.objects.filter(m3u_account__name__contains='MAC Portal')
            count = relations.count()
            relations.delete()
            
            Movie.objects.filter(m3u_relations__isnull=True).delete()
            M3UAccount.objects.filter(name__contains='MAC Portal').delete()
            
            return {"status": "success", "message": f"✅ {count} Filme gelöscht"}
        except Exception as e:
            return {"status": "error", "message": str(e)}
    
    def _extract_year(self, year_value):
        if not year_value:
            return None
        try:
            match = re.search(r'(\d{4})', str(year_value))
            if match:
                year = int(match.group(1))
                if 1900 <= year <= 2100:
                    return year
        except:
            pass
        return None
    
    def _matches_country_filter(self, name, allowed_countries):
        if not name or not allowed_countries:
            return False
        pattern = r'[┃|\[\(]?([A-Z]{2})[┃|\]\)]?[\s✨:|\-]'
        match = re.search(pattern, name)
        return match and match.group(1) in allowed_countries

    
    def _import_live_tv(self, portal_url, macs, proxy, portal_name, country_filter, auto_create_channels, channel_profile, settings, logger_ctx):
        """
        Importiert Live TV Channels als M3U mit Streams.
        
        Optional: Erstellt automatisch Channels (wenn auto_create_channels=True)
        Standard: Nur Streams (User erstellt Channels manuell)
        """
        logger_ctx.info(f"📺 Live TV Import vom Portal: {portal_name}")
        logger_ctx.info(f"⚙️ Auto-Create Channels: {auto_create_channels}")
        
        try:
            import os
            import re
            from apps.m3u.models import M3UAccount
            
            # Parse Ländercode-Filter
            allowed_countries = None
            if country_filter:
                allowed_countries = [c.strip().upper() for c in country_filter.split(",") if c.strip()]
                logger_ctx.info(f"Ländercode-Filter aktiv: {allowed_countries}")
            
            # Hole Kanäle und Genres
            channels = None
            genres = None
            
            for mac in macs:
                try:
                    token = self.stb_client.get_token(portal_url, mac, proxy)
                    if token:
                        self.stb_client.get_profile(portal_url, mac, token, proxy)
                        channels = self.stb_client.get_all_channels(portal_url, mac, token, proxy)
                        genres = self.stb_client.get_genre_names(portal_url, mac, token, proxy)
                        if channels and genres:
                            break
                except Exception as e:
                    logger_ctx.error(f"Fehler beim Kanal-Abruf mit MAC {mac}: {e}")
                    continue
            
            if not channels or not genres:
                return {"status": "error", "message": "Konnte Kanäle nicht abrufen"}
            
            # Filtere Kanäle nach Ländercode
            if allowed_countries:
                original_count = len(channels)
                filtered_channels = []
                
                for channel in channels:
                    channel_name = channel.get("name", "")
                    country_code = self._extract_country_code(channel_name)
                    
                    if country_code and country_code in allowed_countries:
                        filtered_channels.append(channel)
                
                channels = filtered_channels
                logger_ctx.info(f"Kanäle gefiltert: {original_count} → {len(channels)} (Ländercodes: {allowed_countries})")
                
                if not channels:
                    return {
                        "status": "error",
                        "message": f"Keine Kanäle mit den angegebenen Ländercodes gefunden: {', '.join(allowed_countries)}"
                    }
            
            # Generiere M3U-Content
            safe_portal_name = "".join(c if c.isalnum() or c in (' ', '-', '_') else '_' for c in portal_name)
            safe_portal_name = safe_portal_name.strip()
            
            account_name = safe_portal_name
            m3u_lines = ['#EXTM3U']
            imported_tvg_ids = set()
            
            # Extrahiere Base-URL
            base_url = portal_url.replace("/portal.php", "")
            
            for channel in channels:
                channel_id = str(channel["id"])
                channel_name = str(channel["name"])
                channel_number = str(channel.get("number", ""))
                genre_id = str(channel.get("tv_genre_id", ""))
                genre_name = genres.get(genre_id, "")
                logo = str(channel.get("logo", ""))
                cmd = str(channel.get("cmd", ""))
                
                # Erstelle EXTINF-Zeile
                extinf_parts = ['#EXTINF:-1']
                
                if channel_number:
                    extinf_parts.append(f'tvg-chno="{channel_number}"')
                
                # Bereinige Kanalnamen wenn aktiviert
                clean_name = channel_name
                display_name = channel_name
                
                if settings.get("clean_channel_names", False):
                    # Schritt 1: Entferne Prefix
                    clean_name = self._remove_prefix(clean_name)
                    # Schritt 2: Entferne Sonderzeichen
                    clean_name = self._remove_special_chars(clean_name)
                    
                    if channel_name != clean_name:
                        logger_ctx.debug(f"Kanalname bereinigt: '{channel_name}' → '{clean_name}'")
                    
                    # Display-Name ist immer bereinigt
                    display_name = clean_name
                
                # tvg-name: Standard = Original, Optional = bereinigt
                tvg_name = channel_name  # Standard: Original für EPG-Matching
                if settings.get("clean_channel_names", False) and settings.get("clean_tvg_name", False):
                    tvg_name = clean_name  # Optional: Auch tvg-name bereinigen
                
                tvg_id = f"{safe_portal_name.lower().replace(' ', '_')}_{channel_id}"
                extinf_parts.append(f'tvg-id="{tvg_id}"')
                
                if tvg_name:
                    extinf_parts.append(f'tvg-name="{tvg_name}"')
                
                if logo:
                    extinf_parts.append(f'tvg-logo="{logo}"')
                
                if genre_name:
                    extinf_parts.append(f'group-title="{genre_name}"')
                
                # Extrahiere Channel-ID für URL
                ch_id = None
                if cmd:
                    cmd_clean = cmd.replace("ffmpeg ", "").strip()
                    if "localhost" in cmd_clean:
                        ch_id_match = re.search(r'/ch/(\d+)', cmd_clean)
                        if ch_id_match:
                            ch_id = ch_id_match.group(1)
                
                if not ch_id:
                    logger_ctx.debug(f"Überspringe Kanal {channel_id} ohne gültige Channel-ID")
                    continue
                
                # Erstelle dynamische Stream-URL (KEIN API-Call nötig!)
                extinf_line = ' '.join(extinf_parts) + f',{display_name}'
                m3u_lines.append(extinf_line)
                stream_url = f"{base_url}/play/live.php?mac={macs[0]}&stream={ch_id}&extension=ts"
                m3u_lines.append(stream_url)
                
                imported_tvg_ids.add(tvg_id)
            
            # Speichere M3U-Datei
            output_dir = "/app/sources"
            if not os.path.exists(output_dir):
                output_dir = os.path.join(os.getcwd(), "sources")
                os.makedirs(output_dir, exist_ok=True)
            
            safe_filename = safe_portal_name.replace(' ', '_')
            output_file = os.path.join(output_dir, f"{safe_filename}_live_tv.m3u")
            
            with open(output_file, 'wb') as f:
                for line in m3u_lines:
                    f.write((line + '\n').encode('utf-8'))
            
            logger_ctx.info(f"✅ M3U-Datei gespeichert: {output_file}")
            
            # Erstelle M3U-Account
            existing_account = M3UAccount.objects.filter(name=account_name).first()
            
            if existing_account:
                logger_ctx.info(f"Account existiert bereits, aktualisiere: {account_name}")
                existing_account.url = f"file://{output_file}"
                
                # MOD-Support: Update proxy in BEIDEN Feldern
                if proxy:
                    if hasattr(existing_account, 'proxy'):
                        existing_account.proxy = proxy
                    if hasattr(existing_account, 'proxy_std_xc'):
                        existing_account.proxy_std_xc = proxy
                    logger_ctx.info(f"✅ Proxy für M3U Account aktualisiert: {proxy}")
                
                existing_account.save()
                account_id = existing_account.id
            else:
                logger_ctx.info(f"Erstelle neuen M3U-Account: {account_name}")
                new_account = M3UAccount(name=account_name)
                
                # Setze Account-Type
                if hasattr(new_account, 'account_type'):
                    new_account.account_type = 'STD'
                
                if hasattr(new_account, 'url'):
                    new_account.url = f"file://{output_file}"
                elif hasattr(new_account, 'file_path'):
                    new_account.file_path = output_file
                elif hasattr(new_account, 'path'):
                    new_account.path = output_file
                
                # MOD-Support: Setze proxy in BEIDE Felder (proxy UND proxy_std_xc)
                if proxy:
                    # proxy - wird im WebUI angezeigt (Serializer)
                    if hasattr(new_account, 'proxy'):
                        new_account.proxy = proxy
                    # proxy_std_xc - wird beim Streaming verwendet (MOD)
                    if hasattr(new_account, 'proxy_std_xc'):
                        new_account.proxy_std_xc = proxy
                    logger_ctx.info(f"✅ Proxy für M3U Account gesetzt: {proxy}")
                
                new_account.save()
                account_id = new_account.id
                
                # WICHTIG: Proxy nochmal setzen NACH dem Save (Serializer könnte überschreiben)
                if proxy:
                    update_fields = {}
                    if hasattr(new_account, 'proxy'):
                        update_fields['proxy'] = proxy
                        logger_ctx.info(f"🔍 DEBUG: Setze 'proxy' Feld auf: {proxy}")
                    if hasattr(new_account, 'proxy_std_xc'):
                        update_fields['proxy_std_xc'] = proxy
                        logger_ctx.info(f"🔍 DEBUG: Setze 'proxy_std_xc' Feld auf: {proxy}")
                    if update_fields:
                        M3UAccount.objects.filter(id=account_id).update(**update_fields)
                        logger_ctx.info(f"✅ Proxy nochmal gesetzt nach Save: {proxy}")
                        
                        # Verify: Lese Account nochmal aus DB
                        verify_account = M3UAccount.objects.get(id=account_id)
                        logger_ctx.info(f"🔍 VERIFY: proxy = {getattr(verify_account, 'proxy', 'NICHT VORHANDEN')}")
                        logger_ctx.info(f"🔍 VERIFY: proxy_std_xc = {getattr(verify_account, 'proxy_std_xc', 'NICHT VORHANDEN')}")
            
            logger_ctx.info(f"✅ M3U-Account erstellt/aktualisiert: {account_name} (ID: {account_id})")
            
            # Erstelle M3U Account Profiles für Failover (wenn mehrere MACs)
            if len(macs) > 1:
                logger_ctx.info(f"⚙️ Erstelle {len(macs)-1} Failover-Profile für MAC-Rotation...")
                try:
                    from apps.m3u.models import M3UAccountProfile
                    
                    first_mac = macs[0]  # Erste MAC ist in allen URLs
                    
                    for i, mac in enumerate(macs[1:], start=2):  # Ab zweiter MAC
                        profile_name = str(i)
                        
                        # Prüfe ob Profil bereits existiert
                        profile, created = M3UAccountProfile.objects.get_or_create(
                            m3u_account_id=account_id,
                            name=profile_name,
                            defaults={
                                'is_default': False,
                                'max_streams': 1,
                                'is_active': True,
                                'search_pattern': first_mac,
                                'replace_pattern': mac
                            }
                        )
                        
                        if created:
                            logger_ctx.info(f"  ✅ Profil '{profile_name}' erstellt: {first_mac} → {mac}")
                        else:
                            # Update existing profile
                            profile.search_pattern = first_mac
                            profile.replace_pattern = mac
                            profile.max_streams = 1
                            profile.is_active = True
                            profile.save()
                            logger_ctx.info(f"  ✅ Profil '{profile_name}' aktualisiert: {first_mac} → {mac}")
                    
                    logger_ctx.info(f"✅ {len(macs)-1} Failover-Profile erstellt/aktualisiert")
                    
                except Exception as profile_error:
                    logger_ctx.warning(f"⚠️ Konnte Failover-Profile nicht erstellen: {profile_error}")
                    import traceback
                    logger_ctx.debug(traceback.format_exc())
            
            # Trigger Refresh (erstellt Streams)
            try:
                from apps.m3u.tasks import refresh_m3u_account
                refresh_m3u_account.delay(account_id)
                logger_ctx.info(f"✅ Refresh-Task gestartet für Account {account_id}")
            except Exception as refresh_error:
                logger_ctx.debug(f"Konnte Refresh-Task nicht starten: {refresh_error}")
            
            # Optional: Channels erstellen
            if auto_create_channels:
                logger_ctx.info(f"⚙️ Erstelle Channels automatisch (Profil: {channel_profile})...")
                # Hier würde _add_channels_to_profile() aufgerufen werden
                # Aber das ist komplex und braucht Wartezeit für Refresh
                logger_ctx.warning("⚠️ Auto-Create Channels noch nicht implementiert")
                logger_ctx.info("💡 Nutze Dispatcharr Auto-Channel-Sync stattdessen")
            
            logger_ctx.info(f"🎉 Live TV Import abgeschlossen: {len(imported_tvg_ids)} Streams")
            
            result = {
                "status": "success",
                "message": f"✅ {len(imported_tvg_ids)} Live TV Streams importiert",
                "account_id": account_id,
                "account_name": account_name,
                "file_path": output_file,
                "stream_count": len(imported_tvg_ids),
                "channels_auto_created": False
            }
            
            if not auto_create_channels:
                result["info"] = "Streams wurden importiert. Channels können in Dispatcharr UI erstellt werden (Channel Groups → Auto-Channel-Sync)"
            
            return result
            
        except Exception as e:
            logger_ctx.error(f"Fehler: {e}")
            import traceback
            logger_ctx.error(traceback.format_exc())
            return {"status": "error", "message": str(e)}
    
    def _extract_country_code(self, name):
        """
        Extrahiert den Ländercode aus einem Kanalnamen.
        Unterstützt alle gängigen Prefix-Formate und extrahiert nur den 2-3 Buchstaben Code.
        
        Beispiele:
        - ┃DE┃ SERIEN → DE
        - |NL| SPORT → NL
        - DE ✨ RADIO → DE
        - [UK] News → UK
        - (US) Movies → US
        - FR: Channel → FR
        - DE - Regional → DE
        """
        if not name:
            return None
        
        # Erweiterte Muster für Ländercode-Extraktion
        patterns = [
            r'^┃([A-Z]{2,3})┃',                    # ┃DE┃
            r'^\|([A-Z]{2,3})\|',                  # |DE|
            r'^\[([A-Z]{2,3})\]',                  # [DE]
            r'^\(([A-Z]{2,3})\)',                  # (DE)
            r'^([A-Z]{2,3})\s*[✨🔥⭐🎬🎵🎮📺🌟💎🎯🔴⚡💥🌈🎪🎭🎨🎤🎧🎼🎹🎺🎻🥁🎸]+', # DE ✨
            r'^([A-Z]{2,3})\s*[:|\-]\s*',          # DE:, DE|, DE -, DE-
            r'^([A-Z]{2,3})\s+(?=[A-Z])',          # DE SERIEN
            r'^([A-Z]{2,3})\s*\*',                 # DE*
            r'^([A-Z]{2,3})\s*►',                  # DE►
            r'^([A-Z]{2,3})\s*»',                  # DE»
            r'^([A-Z]{2,3})\s*•',                  # DE•
            r'^([A-Z]{2,3})\s*→',                  # DE→
        ]
        
        for pattern in patterns:
            match = re.match(pattern, name.strip())
            if match:
                return match.group(1).upper()
        
        return None
    
    def _extract_prefix(self, channel_name):
        """
        Extrahiert Prefix aus Kanalnamen.
        Unterstützt Formate wie:
        - ┃DE┃ SERIEN 24/7
        - |DE| SERIEN 24/7
        - DE ✨ RADIO
        - [DE] Channel Name
        - (DE) Channel Name
        - DE: Channel Name
        - DE | Channel Name
        """
        if not channel_name:
            return None
        
        # Muster für verschiedene Prefix-Formate
        patterns = [
            r'^(┃[^┃]+┃)',           # ┃DE┃
            r'^(\|[^\|]+\|)',         # |DE|
            r'^\[([^\]]+)\]',         # [DE]
            r'^\(([^\)]+)\)',         # (DE)
            r'^([A-Z]{2,3}\s*[✨🔥⭐🎬🎵🎮📺🌟💎🎯🔴⚡💥🌈🎪🎭🎨🎬🎤🎧🎼🎹🎺🎻🥁🎸]+)', # DE ✨, DE 🔥, etc.
            r'^([A-Z]{2,3})\s*[:|\-]', # DE:, DE|, DE-
            r'^([A-Z]{2,3})\s+(?=[A-Z])', # DE SERIEN (DE gefolgt von Großbuchstaben)
        ]
        
        for pattern in patterns:
            match = re.match(pattern, channel_name.strip())
            if match:
                return match.group(1).strip()
        
        return None
    
    def _remove_prefix(self, channel_name):
        """
        Entfernt Prefix aus Kanalnamen.
        
        Beispiele:
        - ┃DE┃ SERIEN 24/7 → SERIEN 24/7
        - |NL| SPORT HD → SPORT HD
        - DE ✨ RADIO → RADIO
        - [UK] News → News
        - (US) Movies → Movies
        - FR: Channel → Channel
        """
        if not channel_name:
            return channel_name
        
        # Muster für verschiedene Prefix-Formate (mit Capture-Group für Rest)
        patterns = [
            r'^┃[^┃]+┃\s*(.+)',                    # ┃DE┃ Rest
            r'^\|[^\|]+\|\s*(.+)',                  # |DE| Rest
            r'^\[[^\]]+\]\s*(.+)',                  # [DE] Rest
            r'^\([^\)]+\)\s*(.+)',                  # (DE) Rest
            r'^[A-Z]{2,3}\s*[✨🔥⭐🎬🎵🎮📺🌟💎🎯🔴⚡💥🌈🎪🎭🎨🎤🎧🎼🎹🎺🎻🥁🎸]+\s*(.+)', # DE ✨ Rest
            r'^[A-Z]{2,3}\s*[:|\-]\s*(.+)',        # DE: Rest, DE| Rest, DE- Rest
            r'^[A-Z]{2,3}\s*\*\s*(.+)',            # DE* Rest
            r'^[A-Z]{2,3}\s*►\s*(.+)',             # DE► Rest
            r'^[A-Z]{2,3}\s*»\s*(.+)',             # DE» Rest
            r'^[A-Z]{2,3}\s*•\s*(.+)',             # DE• Rest
            r'^[A-Z]{2,3}\s*→\s*(.+)',             # DE→ Rest
            r'^[A-Z]{2,3}\s+([A-Z].+)',            # DE SERIEN (DE gefolgt von Großbuchstaben)
        ]
        
        for pattern in patterns:
            match = re.match(pattern, channel_name.strip())
            if match:
                return match.group(1).strip()
        
        # Kein Prefix gefunden, gib Original zurück
        return channel_name
    
    def _remove_special_chars(self, text):
        """
        Entfernt Sonderzeichen, Emojis und nicht-ASCII Zeichen aus Text.
        
        Entfernt:
        - Emojis: ✨, 🔥, ⭐, 🎬, 📺, etc.
        - Symbole: ┃, |, →, ►, », •, etc.
        - Umlaute: ä, ö, ü, ß, etc.
        - Akzente: é, è, à, ñ, etc.
        - Kyrillisch: а, б, в, г, etc.
        - Arabisch: ا, ب, ت, etc.
        - Chinesisch: 中, 文, etc.
        
        Behält:
        - Buchstaben A-Z, a-z
        - Zahlen 0-9
        - Leerzeichen
        - Grundlegende Satzzeichen: . , - _ ( ) [ ]
        
        Beispiele:
        - "ARD HD ✨" → "ARD HD"
        - "┃DE┃ SPORT" → "DE SPORT"
        - "Österreich 🇦🇹" → "Osterreich"
        - "Спорт HD" → "HD"
        """
        if not text:
            return text
        
        # Ersetze Umlaute vor der Bereinigung (optional)
        umlaut_map = {
            'ä': 'ae', 'ö': 'oe', 'ü': 'ue', 'ß': 'ss',
            'Ä': 'Ae', 'Ö': 'Oe', 'Ü': 'Ue',
            'à': 'a', 'á': 'a', 'â': 'a', 'ã': 'a', 'å': 'a',
            'è': 'e', 'é': 'e', 'ê': 'e', 'ë': 'e',
            'ì': 'i', 'í': 'i', 'î': 'i', 'ï': 'i',
            'ò': 'o', 'ó': 'o', 'ô': 'o', 'õ': 'o',
            'ù': 'u', 'ú': 'u', 'û': 'u',
            'ñ': 'n', 'ç': 'c',
        }
        
        for umlaut, replacement in umlaut_map.items():
            text = text.replace(umlaut, replacement)
        
        # Entferne alle nicht-ASCII Zeichen (Emojis, Symbole, Kyrillisch, Arabisch, Chinesisch, etc.)
        # Behalte nur: A-Z, a-z, 0-9, Leerzeichen, . , - _ ( ) [ ]
        cleaned = ''.join(c for c in text if c.isascii() and (c.isalnum() or c in ' .,-_()[]'))
        
        # Entferne mehrfache Leerzeichen
        cleaned = ' '.join(cleaned.split())
        
        return cleaned.strip()
    
    def _check_mac_status(self, portal_url, macs, proxy, logger_ctx):
        """Prüft den Status und Ablaufdatum aller MAC-Adressen."""
        logger_ctx.info(f"Prüfe MAC-Status für {len(macs)} Adressen")
        
        results = []
        active_count = 0
        all_prefixes = set()
        
        for mac in macs:
            try:
                token = self.stb_client.get_token(portal_url, mac, proxy)
                
                if token:
                    expires = self.stb_client.get_expires(portal_url, mac, token, proxy)
                    
                    if expires:
                        # Hole Kanäle, um Prefixes zu analysieren
                        channels = None
                        try:
                            self.stb_client.get_profile(portal_url, mac, token, proxy)
                            channels = self.stb_client.get_all_channels(portal_url, mac, token, proxy)
                        except Exception as e:
                            logger_ctx.debug(f"Konnte Kanäle für MAC {mac} nicht abrufen: {e}")
                        
                        # Extrahiere Prefixes aus Kanalnamen
                        prefixes = set()
                        if channels:
                            for channel in channels:
                                channel_name = channel.get("name", "")
                                prefix = self._extract_prefix(channel_name)
                                if prefix:
                                    prefixes.add(prefix)
                                    all_prefixes.add(prefix)
                        
                        results.append({
                            "mac": mac,
                            "status": "active",
                            "expires": expires,
                            "channel_count": len(channels) if channels else 0,
                            "prefixes": sorted(list(prefixes))
                        })
                        active_count += 1
                    else:
                        results.append({
                            "mac": mac,
                            "status": "inactive",
                            "message": "Kein Ablaufdatum verfügbar"
                        })
                else:
                    results.append({
                        "mac": mac,
                        "status": "inactive",
                        "message": "Kein Token erhalten"
                    })
            
            except Exception as e:
                results.append({
                    "mac": mac,
                    "status": "error",
                    "message": str(e)
                })
        
        return {
            "status": "success",
            "message": f"{active_count}/{len(macs)} MAC-Adressen aktiv",
            "active_count": active_count,
            "total_count": len(macs),
            "all_prefixes": sorted(list(all_prefixes)),
            "results": results
        }
    
    def _import_xmltv(self, portal_url, macs, proxy, portal_name, logger_ctx):
        """Lädt die XMLTV-EPG-Datei vom Portal herunter und speichert sie in /app/sources."""
        logger_ctx.info(f"📡 Lade XMLTV-EPG vom Portal: {portal_name}")
        
        try:
            import os
            
            # Extrahiere Base-URL (ohne /portal.php)
            base_url = portal_url.replace("/portal.php", "")
            
            # Verwende die erste MAC-Adresse
            mac = macs[0]
            
            # Lade XMLTV-Datei herunter
            proxies = {"http": proxy, "https": proxy} if proxy else None
            headers = {"User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C)"}
            
            xmltv_content = None
            used_method = None
            epg_url = None  # Die URL die wir für die EPG-Quelle verwenden
            
            # Methode 1: API-Endpoint (get_epg_info) - Diese URL für EPG-Quelle verwenden
            api_url = f"{portal_url}?type=itv&action=get_epg_info&period=24&mac={mac}"
            logger_ctx.info(f"Versuche API-Methode: {api_url}")
            
            try:
                # Hole Token für API-Zugriff
                token = self.stb_client.get_token(portal_url, mac, proxy)
                if token:
                    cookies = {"mac": mac, "stb_lang": "en", "timezone": "Europe/London"}
                    api_headers = {
                        "User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C)",
                        "Authorization": f"Bearer {token}",
                    }
                    response = requests.get(api_url, headers=api_headers, cookies=cookies, proxies=proxies, timeout=60)
                    
                    if response.status_code == 200 and len(response.content) > 100:
                        xmltv_content = response.content
                        used_method = "API (get_epg_info)"
                        epg_url = api_url
                        logger_ctx.info("✅ EPG via API-Methode erfolgreich geladen")
            except Exception as e:
                logger_ctx.warning(f"API-Methode fehlgeschlagen: {e}")
            
            # Methode 2: Fallback zu xmltv.php
            if not xmltv_content:
                xmltv_url = f"{base_url}/xmltv.php?username={mac}&password={mac}"
                logger_ctx.info(f"Versuche xmltv.php-Methode: {xmltv_url}")
                
                try:
                    response = requests.get(xmltv_url, headers=headers, proxies=proxies, timeout=60)
                    
                    if response.status_code == 200 and len(response.content) > 100:
                        xmltv_content = response.content
                        used_method = "xmltv.php"
                        epg_url = xmltv_url
                        logger_ctx.info("✅ EPG via xmltv.php erfolgreich geladen")
                except Exception as e:
                    logger_ctx.warning(f"xmltv.php-Methode fehlgeschlagen: {e}")
            
            # Prüfe ob EPG-Daten geladen wurden
            if not xmltv_content:
                return {
                    "status": "error",
                    "message": "Konnte XMLTV-Datei nicht laden (beide Methoden fehlgeschlagen)"
                }
            
            if len(xmltv_content) < 100:
                return {
                    "status": "error",
                    "message": "XMLTV-Datei ist zu klein oder leer"
                }
            
            # Speichere XMLTV-Datei
            output_dir = "/app/sources"
            if not os.path.exists(output_dir):
                output_dir = os.path.join(os.getcwd(), "sources")
                os.makedirs(output_dir, exist_ok=True)
            
            # Sanitize portal name für Dateinamen
            safe_portal_name = "".join(c if c.isalnum() or c in (' ', '-', '_') else '_' for c in portal_name)
            safe_filename = safe_portal_name.replace(' ', '_').lower()
            output_file = os.path.join(output_dir, f"{safe_filename}_epg.xml")
            
            # Schreibe XMLTV-Datei
            with open(output_file, 'wb') as f:
                f.write(xmltv_content)
            
            file_size_mb = len(xmltv_content) / (1024 * 1024)
            logger_ctx.info(f"✅ XMLTV-Datei gespeichert: {output_file} ({file_size_mb:.2f} MB) via {used_method}")
            
            # Registriere EPG-Quelle über Dispatcharr API mit direkter URL
            epg_source_name = f"{portal_name} EPG"
            epg_source_id = None
            
            if epg_url:
                try:
                    from apps.epg.models import EPGSource
                    
                    logger_ctx.info(f"Registriere EPG-Quelle: {epg_source_name}")
                    logger_ctx.info(f"EPG-URL: {epg_url}")
                    
                    # Prüfe ob EPG-Quelle bereits existiert
                    epg_source, created = EPGSource.objects.get_or_create(
                        name=epg_source_name,
                        defaults={
                            'source_type': 'xmltv',
                            'url': epg_url,
                            'is_active': True,
                        }
                    )
                    
                    # Aktualisiere Felder falls bereits vorhanden
                    if not created:
                        epg_source.source_type = 'xmltv'
                        epg_source.url = epg_url
                        epg_source.is_active = True
                        epg_source.save()
                        logger_ctx.info(f"✅ EPG-Quelle aktualisiert: {epg_source_name} (ID: {epg_source.id})")
                    else:
                        logger_ctx.info(f"✅ EPG-Quelle erstellt: {epg_source_name} (ID: {epg_source.id})")
                    
                    epg_source_id = epg_source.id
                    
                except Exception as epg_error:
                    logger_ctx.warning(f"Konnte EPG-Quelle nicht registrieren: {epg_error}")
                    logger_ctx.warning("EPG-Datei wurde gespeichert, muss aber manuell in Dispatcharr hinzugefügt werden")
            else:
                logger_ctx.warning("Keine EPG-URL verfügbar, EPG-Quelle wird nicht registriert")
            
            result = {
                "status": "success",
                "message": f"✅ XMLTV-EPG erfolgreich importiert ({file_size_mb:.2f} MB) via {used_method}",
                "file_path": output_file,
                "file_size_bytes": len(xmltv_content),
                "method": used_method,
                "epg_url": epg_url
            }
            
            if epg_source_id:
                result["epg_source_id"] = epg_source_id
                result["epg_source_name"] = epg_source_name
            
            return result
            
        except Exception as e:
            logger_ctx.error(f"Fehler beim XMLTV-Import: {e}")
            import traceback
            logger_ctx.error(traceback.format_exc())
            return {
                "status": "error",
                "message": f"Fehler beim XMLTV-Import: {str(e)}"
            }
    
    def _show_auto_update_status(self, settings, logger_ctx):
        """Zeigt den Status des automatischen Updates."""
        try:
            auto_update_enabled = settings.get('auto_update_enabled', False)
            interval_hours = settings.get('auto_update_interval_hours', 6)
            
            logger_ctx.info("=" * 60)
            logger_ctx.info("MACBridge Auto-Update Status")
            logger_ctx.info("=" * 60)
            logger_ctx.info("")
            
            if auto_update_enabled:
                logger_ctx.info("✅ Auto-Update ist AKTIVIERT")
                logger_ctx.info(f"   Intervall: Alle {interval_hours} Stunden")
                logger_ctx.info("")
                logger_ctx.info("Geplante Tasks:")
                logger_ctx.info(f"  • VOD-Import: Alle {interval_hours} Stunden um :00")
                logger_ctx.info(f"  • Live TV-Import: Alle {interval_hours} Stunden um :30")
                logger_ctx.info("")
                logger_ctx.info("⚠️ HINWEIS: Auto-Update Tasks müssen in Celery Beat konfiguriert werden.")
                logger_ctx.info("Die Tasks werden automatisch von Celery Beat ausgeführt.")
                logger_ctx.info("Logs findest du in den Dispatcharr-Logs.")
                logger_ctx.info("")
                logger_ctx.info("💡 Zum Deaktivieren:")
                logger_ctx.info("   Setze 'Auto-Update aktivieren' auf 'false' in den Plugin-Einstellungen")
            else:
                logger_ctx.info("❌ Auto-Update ist DEAKTIVIERT")
                logger_ctx.info("")
                logger_ctx.info("💡 Zum Aktivieren:")
                logger_ctx.info("   1. Gehe zu den Plugin-Einstellungen")
                logger_ctx.info("   2. Setze 'Auto-Update aktivieren' auf 'true'")
                logger_ctx.info("   3. Optional: Passe 'Update-Intervall (Stunden)' an")
                logger_ctx.info("   4. Speichere die Einstellungen")
                logger_ctx.info("")
                logger_ctx.info("Nach der Aktivierung werden automatisch alle")
                logger_ctx.info(f"{interval_hours} Stunden neue VODs und Live TV importiert.")
                logger_ctx.info("")
                logger_ctx.info("⚠️ HINWEIS: Celery Beat muss separat konfiguriert werden!")
            
            logger_ctx.info("")
            logger_ctx.info("=" * 60)
            
            # Prüfe ob Celery Beat läuft
            try:
                from celery import current_app
                inspect = current_app.control.inspect()
                scheduled = inspect.scheduled()
                
                if scheduled:
                    logger_ctx.info("")
                    logger_ctx.info("📊 Celery Beat Status: Läuft")
                    
                    # Suche nach MACBridge Tasks
                    macbridge_tasks = []
                    for worker, tasks in scheduled.items():
                        for task in tasks:
                            if 'macbridge' in task.get('name', '').lower():
                                macbridge_tasks.append(task)
                    
                    if macbridge_tasks:
                        logger_ctx.info(f"   Gefundene MACBridge Tasks: {len(macbridge_tasks)}")
                else:
                    logger_ctx.info("")
                    logger_ctx.info("⚠️  Celery Beat Status: Nicht erreichbar")
                    logger_ctx.info("   Stelle sicher, dass Celery Beat läuft")
            except Exception as e:
                logger_ctx.info("")
                logger_ctx.info(f"⚠️  Celery Status konnte nicht geprüft werden: {e}")
            
            return {
                "status": "success",
                "message": f"Auto-Update ist {'aktiviert' if auto_update_enabled else 'deaktiviert'}",
                "auto_update_enabled": auto_update_enabled,
                "interval_hours": interval_hours
            }
            
        except Exception as e:
            logger_ctx.error(f"Fehler beim Prüfen des Auto-Update-Status: {e}")
            import traceback
            logger_ctx.error(traceback.format_exc())
            return {
                "status": "error",
                "message": f"Fehler beim Prüfen des Auto-Update-Status: {str(e)}"
            }

